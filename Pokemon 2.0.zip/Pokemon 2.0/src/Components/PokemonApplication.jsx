import React, { useState, useEffect } from "react";
import Pokemon from "./Pokemon"; 

function PokemonApplication() {
  const [pokemonList, setPokemonList] = useState([]);
  const [pokemonUrl, setPokemonUrl] = useState("");
  const [currentPokemon, setCurrentPokemon] = useState();

  useEffect(() => {
    let fetchPokemons = async () => {
      let response = await fetch("https://pokeapi.co/api/v2/pokemon?limit=151");
      let data = await response.json();
      console.log(data.results)
      setPokemonList(data.results);
    }

    fetchPokemons();
  }, [])

    let fetchPokemonData = async () => {
    let response = await fetch(pokemonUrl);
    let data = await response.json();
    console.log(data)
    setCurrentPokemon(data);
    }

  return(
    <>
    <select onChange={e => setPokemonUrl(e.target.value)}>
     <option>Select Pokemon</option>
     {pokemonList.map(pokemon => (
     <option value={pokemon.url}>{pokemon.name}</option>
  ))}
    </select>

    <button onClick={fetchPokemonData}>Get pokemon data</button>
    {currentPokemon && <Pokemon data={currentPokemon}></Pokemon>}
    </>
    )}


export default PokemonApplication;

