import React, { useState } from "react";
import PokemonApplication from "./Components/PokemonApplication";

function App() {
  const [startApp, setStartApp] = useState(true);

  let handleStartApp = () => {
    setStartApp(false);
  }

  if (startApp) {
    return (
        <button onClick={handleStartApp}>Start Pokemon App</button>
    );
  }

  return (
      <PokemonApplication/>
  );}

export default App;

